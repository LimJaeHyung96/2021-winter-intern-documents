<?php

 $conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
 
 $query = "select * from er_msg_tb";
 
 $result = mysqli_query($conn, $query);

	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
	$res = $row["MSG_TOKN"];
		
	$ch = curl_init("https://fcm.googleapis.com/fcm/send");
	$header = array("Content-Type:application/json", "Authorization:key=AAAA_ycXFSE:APA91bH71gB26Qc8hdjXlmHjwhnNzEJ5PPqjcf0kSQMfCoROmITeqVW7qvaoHcYgobsTl6UafxpSPaAbBwo4MTxflPtlvACbqTtE0hF0Ifs6OwZqKdDP0_1JS-BpliKdiBNxadEgAG8b");
	$data = array(
	 "to" => $res,
     "data" => array(
         "title"   => "보고서 알림",
         "message" => "새로운 보고서가 등록되었습니다.")
         );
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
	curl_exec($ch);
	}
?>