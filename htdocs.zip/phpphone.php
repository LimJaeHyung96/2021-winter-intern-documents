<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$query = "select EMP_NAME,EMP_FUNC,EMP_PHNO from er_emp_tb";
	
	$result = mysqli_query($conn, $query);

	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['EMP_NAME'] = urlencode($row[EMP_NAME]);
		$res['EMP_FUNC'] = urlencode($row[EMP_FUNC]);
		$res['EMP_PHNO'] = urlencode($row[EMP_PHNO]);
		$arr["result"][] = $res;
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>