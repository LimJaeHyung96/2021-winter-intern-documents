<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$SPW_PAWD=$_POST['SPW_PAWD'];
	$spc = array('<', '>', '(', ')', '\'', '"', ';', '=', '+', '|', '&', '-', '#', '..');
	$SPW_PAWD = str_replace($spc, ' ', $SPW_PAWD);
	
	$sql = "select SPW_PAWD from er_spw_tb";
	
	$resultset = mysqli_query($conn, $sql);
	$count = mysqli_num_rows($resultset);
	
	$query = "select SPW_PAWD from er_spw_tb where SPW_CHAG = $count";
	
	$result = mysqli_query($conn, $query);

	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['SPW_PAWD'] = urlencode($row[SPW_PAWD]);
		$arr["result"][] = $res;
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>