<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	
	$REP_NUMB=$_POST['REP_NUMB'];
	
	$query = "select BUD_ADDR,REP_CONT,REP_ACTN,REP_DAMG,REP_CAUS,REP_COND,REP_FMCO,PRM_NAME,BUD_CUTM,REP_APRV,PHT_IMGP from er_rep_tb AS r, er_prm_tb AS p , er_bud_tb AS b, er_pht_tb AS i WHERE r.BUD_CODE = b.BUD_CODE AND b.BUD_CODE = p.BUD_CODE AND r.REP_NUMB = '$REP_NUMB' AND i.REP_NUMB = r.REP_NUMB";
	
	$result = mysqli_query($conn, $query);
	
	
	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['BUD_ADDR'] = urlencode($row[BUD_ADDR]);
		$res['REP_CONT'] = urlencode($row[REP_CONT]);
		$res['REP_ACTN'] = urlencode($row[REP_ACTN]);
		$res['REP_DAMG'] = urlencode($row[REP_DAMG]);
		$res['REP_CAUS'] = urlencode($row[REP_CAUS]);
		$res['REP_COND'] = urlencode($row[REP_COND]);
		$res['REP_FMCO'] = urlencode($row[REP_FMCO]);
		$res['PRM_NAME'] = urlencode($row[PRM_NAME]);
		$res['BUD_CUTM'] = urlencode($row[BUD_CUTM]);
		$res['REP_APRV'] = urlencode($row[REP_APRV]);
		$res['PHT_IMGP'] = urlencode($row[PHT_IMGP]);
		$arr["result"][] = $res;
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>