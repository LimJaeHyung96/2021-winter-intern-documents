<?php 
  
    header("Content-Type:text/html; charset=UTF-8"); 
    $file= $_FILES['image']; 
	$file_name= $_POST['imgName'];
    //이미지 파일을 영구보관하기 위해 
    //이미지 파일의 세부정보 얻어오기 
    $srcName= $file['name']; 
    $tmpName= $file['tmp_name']; //php 파일을 받으면 임시저장소에 넣는다. 그곳이 tmp 
	
	echo "$srcName\n"; 
    //임시 저장소 이미지를 원하는 폴더로 이동 
    $dstName= "uploads/".date('Ymd_his')."_".$srcName; 
    $result=move_uploaded_file($tmpName, $dstName);
    if($result){ 
        echo "upload success\n"; 
    }else{ 
        echo "upload fail\n"; 
    } 
	echo "$srcName\n"; 
    echo "$dstName\n"; 
  
  
    // $name, $msg, $dstName, $now DB에 저장 
    // MySQL에 접속 
    $conn= mysqli_connect("localhost","root","kfns","er_appdata"); 
	
	$query = "select * from er_rep_tb";
		
	$resultset = mysqli_query($conn, $query);
	
	
	
	$YEAR= date('Y');
	$COUNT = mysqli_num_rows($resultset);
    //한글 깨짐 방지 
    mysqli_query($conn, "set names utf8"); 
	
	
	//updata하는 쿼리문
	$updatasql="updata er_pht_tb(REP_NUMB,PHT_IMGP) values('$YEAR-$COUNT','$dstName')";
    //insert하는 쿼리문 
    $insertsql="insert into er_pht_tb(REP_NUMB,PHT_IMGP) values('$YEAR-$COUNT','$dstName')"; 
	$updatesql="update er_pht_tb SET REP_NUMB='$YEAR-$COUNT', PHT_IMGP='$dstName' WHERE REP_NUMB='$YEAR-$COUNT'";
  
    $resultSql =mysqli_query($conn, $insertsql); //쿼리를 요청하다.  
    $resultSql =mysqli_query($conn, $updatesql);
    if($resultSql) echo "insert success \n"; 
    else echo "insert fail \n"; 
  
    mysqli_close($conn); 
  
     
?>