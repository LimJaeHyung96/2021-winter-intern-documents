<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$EMP_NUMB=$_POST['EMP_NUMB'];
	$EMP_PAWD=$_POST['EMP_PAWD'];

	$spc = array('<', '>', '(', ')', '\'', '"', ';', '=', '+', '|', '&', '-', '#', '..');
	$EMP_NUMB = str_replace($spc, ' ', $EMP_NUMB);
	$EMP_PAWD = str_replace($spc, ' ', $EMP_PAWD);
	$query = "select * from er_emp_tb where EMP_NUMB = '$EMP_NUMB' and EMP_PAWD = '$EMP_PAWD' and EMP_OUTC = 1";
	
	$result = mysqli_query($conn, $query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 0){
		$res['EMP_LOGIN'] = "fail";
		$arr["result"][] = $res;
	}else{
		$res['EMP_LOGIN'] = "success";
		$arr["result"][] = $res;
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>