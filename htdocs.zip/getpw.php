<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$id=$_POST['id'];
	
	$query = "select EMP_PAWD from er_emp_tb where EMP_NUMB = '$id'";
	
	$result = mysqli_query($conn, $query);
	
	
	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['EMP_PAWD'] = urlencode($row[EMP_PAWD]);
		$arr["result"][] = $res;
		
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>