<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$category=$_POST['category'];
	$search=$_POST['search'];
	$approveValue=$_POST['approveValue'];
	$startDate=$_POST['startDate'];
	$finishDate=$_POST['finishDate'];
	
	if($category == "작성자"){
		$query = "select REP_NUMB,BUD_SHNM,ACC_CONT,REP_DATE,REP_WTER from er_rep_tb AS r, er_acc_tb AS a , er_bud_tb AS b WHERE r.ACC_CODE = a.ACC_CODE AND r.BUD_CODE = b.BUD_CODE and REP_WTER LIKE '%$search%' and r.REP_APRV = $approveValue and REP_WTDT >= '$startDate' AND REP_WTDT <= '$finishDate' ORDER BY REP_WTDT desc";
	}else if($category == "사고"){
		$query = "select REP_NUMB,BUD_SHNM,ACC_CONT,REP_DATE,REP_WTER from er_rep_tb AS r, er_acc_tb AS a , er_bud_tb AS b WHERE r.ACC_CODE = a.ACC_CODE AND r.BUD_CODE = b.BUD_CODE AND ACC_CONT LIKE '%$search%' and r.REP_APRV = $approveValue and REP_WTDT >= '$startDate' AND REP_WTDT <= '$finishDate' ORDER BY REP_WTDT desc";
	}else if($category == "건물"){
		$query = "select REP_NUMB,BUD_SHNM,ACC_CONT,REP_DATE,REP_WTER from er_rep_tb AS r, er_acc_tb AS a , er_bud_tb AS b WHERE r.ACC_CODE = a.ACC_CODE AND r.BUD_CODE = b.BUD_CODE AND BUD_NAME LIKE '%$search%' and r.REP_APRV = $approveValue and REP_WTDT >= '$startDate' AND REP_WTDT <= '$finishDate' ORDER BY REP_WTDT desc";
	}else{
		echo "아무것도 아닙니다.";
	}
	
	$result = mysqli_query($conn, $query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 0){
		$res['REP_NUMB'] = "x";
		$res['BUD_SHNM'] = "x";
		$res['ACC_CONT'] = "x";
		$res['REP_DATE'] = "x";
		$res['REP_WTER'] = "x";
		$arr["result"][] = $res;
	}else{
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$res['REP_NUMB'] = urlencode($row[REP_NUMB]);
			$res['BUD_SHNM'] = urlencode($row[BUD_SHNM]);
			$res['ACC_CONT'] = urlencode($row[ACC_CONT]);
			$res['REP_DATE'] = urlencode($row[REP_DATE]);
			$res['REP_WTER'] = urlencode($row[REP_WTER]);
			$arr["result"][] = $res;
		}
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>