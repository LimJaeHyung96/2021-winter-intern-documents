<?php

  $conn=mysqli_connect( "localhost", "root", "kfns","er_appdata");

    $REP_NUMB=$_POST['REP_NUMB'];
    $aprv=$_POST['aprv'];

    mysqli_query("set names utf8");

    $sql = "UPDATE er_rep_tb SET REP_APRV = '$aprv' WHERE REP_NUMB = '$REP_NUMB';";
	   
	$result = mysqli_query($conn, $sql);

    mysqli_close($conn);

?>