<?php
	$YEAR=date('Y');
	echo $YEAR.'안녕';
?>