<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$query = "SELECT PRM_NAME,PRM_PHNO FROM er_prm_tb UNION SELECT REL_SHNM,REL_PHNO FROM er_rel_tb";
	
	$result = mysqli_query($conn, $query);

	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['PRM_NAME'] = urlencode($row[PRM_NAME]);
		$res['PRM_PHNO'] = urlencode($row[PRM_PHNO]);
		$arr["result"][] = $res;
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>