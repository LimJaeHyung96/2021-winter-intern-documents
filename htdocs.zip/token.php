<?php

    $conn=mysqli_connect( "localhost", "root", "kfns","er_appdata");

    $token=$_POST['token'];
	$EMP_NUMB=$_POST['EMP_NUMB'];

    mysqli_query("set names utf8");
	
	$query = "SELECT * FROM er_tmr_tb";
	$resultset = mysqli_query($conn, $query);
	$COUNT = mysqli_num_rows($resultset);
	
	
	$query2 = "SELECT TMR_TIME FROM er_tmr_tb WHERE TMR_CHAG = $COUNT UNION SELECT BUD_CODE FROM er_emp_tb WHERE EMP_NUMB = '$EMP_NUMB'";
	$result2 = mysqli_query($conn, $query2);
	while ($row = mysqli_fetch_array($result2, MYSQLI_ASSOC)) {
		$res['TMR_TIME'] = urlencode($row[TMR_TIME]);
		$arr["result"][] = $res;
	}
	
	$sql = "INSERT INTO er_msg_tb(MSG_TOKN) VALUES ('$token');";
	$result = mysqli_query($conn, $sql);

	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
    mysqli_close($conn);
?>