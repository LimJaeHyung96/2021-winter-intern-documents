<?php

  $conn=mysqli_connect( "localhost", "root", "kfns","er_appdata");
		
		$query = "select * from er_rep_tb";
		
		$resultset = mysqli_query($conn, $query);
		
		$YEAR=date('Y');
		$COUNT = mysqli_num_rows($resultset);
        $INS_ONE=$_POST['INS_ONE'];
        $INS_TWO=$_POST['INS_TWO'];
        $INS_THREE=$_POST['INS_THREE'];
		$INS_FOUR=$_POST['INS_FOUR'];
		$INS_FIVE=$_POST['INS_FIVE'];
		$INS_SIX=$_POST['INS_SIX'];
		$INS_SEVEN=$_POST['INS_SEVEN'];
		$INS_EIGHT=$_POST['INS_EIGHT'];
		$INS_NINE=$_POST['INS_NINE'];
		$token=$_POST['token'];
		$title=$_POST['title'];

      mysqli_query("set names utf8");
	  
	   $query2 = "select REP_NUMB from er_pht_tb where REP_NUMB = '$YEAR-$COUNT'";
	   $result2 = mysqli_query($conn, $query2);
	   $count2 = mysqli_num_rows($result2);
	   if($count2 == 0){
		   $sql3 = "INSERT INTO er_pht_tb(REP_NUMB,PHT_WTER) VALUES ('$YEAR-$COUNT','$INS_EIGHT');";
		   $result = mysqli_query($conn, $sql3);
	   }

       $sql = "INSERT INTO er_rep_tb(REP_NUMB,EMP_NUMB,BUD_CODE,ACC_CODE,REP_FLOR,REP_CONT,PRM_CODE,REP_APRV,REP_WTER,REP_DATE) VALUES
	   ('$YEAR-$COUNT','$INS_ONE','$INS_TWO','$INS_THREE','$INS_FOUR','$INS_FIVE','$INS_SIX','$INS_SEVEN','$INS_EIGHT','$INS_NINE');";
	   
	   $result = mysqli_query($conn, $sql);
	   
	   $sql2 = "select * from er_msg_tb where MSG_TOKN not in('$token')";
	   //select * from er_msg_tb -> 확인용 query
	   
	   $resultsend = mysqli_query($conn, $sql2);

	while ($row = mysqli_fetch_array($resultsend, MYSQLI_ASSOC)) {
	$token = $row["MSG_TOKN"];
		
	$ch = curl_init("https://fcm.googleapis.com/fcm/send");
	$header = array("Content-Type:application/json", "Authorization:key=AAAA_ycXFSE:APA91bH71gB26Qc8hdjXlmHjwhnNzEJ5PPqjcf0kSQMfCoROmITeqVW7qvaoHcYgobsTl6UafxpSPaAbBwo4MTxflPtlvACbqTtE0hF0Ifs6OwZqKdDP0_1JS-BpliKdiBNxadEgAG8b");
	$data = array(
	 "to" => $token,
     "data" => array(
         "body"   => "새 보고서 알림",
         "title" => "$title")
         );
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));
	curl_exec($ch);
	}

    mysqli_close($conn);

?>