<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$query = "select REP_NUMB,BUD_SHNM,ACC_CONT,REP_DATE,REP_WTER,REP_WTDT from er_rep_tb AS r, er_acc_tb AS a , er_bud_tb AS b WHERE r.ACC_CODE = a.ACC_CODE AND r.BUD_CODE = b.BUD_CODE AND r.REP_APRV = 2 ORDER BY REP_WTDT desc";
	
	$result = mysqli_query($conn, $query);
	
	$count = mysqli_num_rows($result);
	
	if($count == 0){
		$res['REP_NUMB'] = "x";
		$res['BUD_SHNM'] = "x";
		$res['ACC_CONT'] = "x";
		$res['REP_DATE'] = "x";
		$res['REP_WTER'] = "x";
		$res['REP_WTDT'] = "x";
		$arr["result"][] = $res;
	}else{
		while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
			$res['REP_NUMB'] = urlencode($row[REP_NUMB]);
			$res['BUD_SHNM'] = urlencode($row[BUD_SHNM]);
			$res['ACC_CONT'] = urlencode($row[ACC_CONT]);
			$res['REP_DATE'] = urlencode($row[REP_DATE]);
			$res['REP_WTER'] = urlencode($row[REP_WTER]);
			$res['REP_WTDT'] = urlencode($row[REP_WTDT]);
			$arr["result"][] = $res;
		}
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>