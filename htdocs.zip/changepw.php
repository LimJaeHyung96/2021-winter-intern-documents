<?php

  $conn=mysqli_connect( "localhost", "root", "kfns","er_appdata");

    $id=$_POST['id'];
    $pw=$_POST['pw'];

    mysqli_query("set names utf8");

    $sql = "UPDATE er_emp_tb SET EMP_PAWD = '$pw' WHERE EMP_NUMB = '$id';";
	   
	$result = mysqli_query($conn, $sql);

    mysqli_close($conn);

?>