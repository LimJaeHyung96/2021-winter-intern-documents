<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$TMR_TIME=$_POST['TMR_TIME'];

	$spc = array('<', '>', '(', ')', '\'', '"', ';', '=', '+', '|', '&', '-', '#', '..');
	$TMR_TIME = str_replace($spc, ' ', $TMR_TIME);
	
	$query = "INSERT INTO er_tmr_tb(TMR_TIME,TMR_WTER) VALUES ('$TMR_TIME','임재형')";
	
	$result = mysqli_query($conn, $query);

	mysqli_close($conn);
?>