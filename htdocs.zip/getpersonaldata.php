<?php

	$conn = mysqli_connect("localhost", "root", "kfns","er_appdata");
	$id=$_POST['id'];
	
	$query = "SELECT EMP_NAME,p.BUD_CODE,p.PRM_CODE,PRM_NAME,BUD_SHNM,BUD_ADDR,BUD_CUTM,PRM_PHNO FROM er_emp_tb AS e, er_prm_tb AS p, er_bud_tb AS b WHERE emp_numb = '$id' AND e.BUD_CODE = p.BUD_CODE AND e.BUD_CODE = b.BUD_CODE";
	
	$result = mysqli_query($conn, $query);
	
	
	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
		$res['EMP_NAME'] = urlencode($row[EMP_NAME]);
		$res['BUD_CODE'] = urlencode($row[BUD_CODE]);
		$res['PRM_CODE'] = urlencode($row[PRM_CODE]);
		$res['PRM_NAME'] = urlencode($row[PRM_NAME]);
		$res['BUD_SHNM'] = urlencode($row[BUD_SHNM]);
		$res['BUD_ADDR'] = urlencode($row[BUD_ADDR]);
		$res['BUD_CUTM'] = urlencode($row[BUD_CUTM]);
		$res['PRM_PHNO'] = urlencode($row[PRM_PHNO]);
		$arr["result"][] = $res;
		
	}
	
	$json = json_encode ($arr);
	$json = urldecode ($json);
	print $json;
	mysqli_close($conn);
?>