<?php

  $conn=mysqli_connect( "localhost", "root", "kfns","er_appdata");

    $REP_NUMB=$_POST['REP_NUMB'];
    $REP_CONT=$_POST['REP_CONT'];
	$REP_ACTN=$_POST['REP_ACTN'];
	$REP_DAMG=$_POST['REP_DAMG'];
	$REP_CAUS=$_POST['REP_CAUS'];
	$REP_COND=$_POST['REP_COND'];

    mysqli_query("set names utf8");

    $sql = "UPDATE er_rep_tb SET REP_CONT = '$REP_CONT', REP_ACTN ='$REP_ACTN', REP_DAMG = '$REP_DAMG', REP_CAUS = '$REP_CAUS', REP_COND = '$REP_COND' WHERE REP_NUMB = '$REP_NUMB';";
	   
	$result = mysqli_query($conn, $sql);

    mysqli_close($conn);

?>